#!/bin/sh
import -silent -border -frame -screen -synchronize ~/screenshot-`date '+%Y%m%d-%H%M%S'`.png
