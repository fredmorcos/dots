#!/bin/sh
import -silent -screen -synchronize -window root ~/screenshot-`date '+%Y%m%d-%H%M%S'`.png
